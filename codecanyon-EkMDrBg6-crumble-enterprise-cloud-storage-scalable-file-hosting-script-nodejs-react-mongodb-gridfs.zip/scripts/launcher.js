require('colors');
const prompts = require('prompts');
const pkg = require('./package.json');
const { isFQDN, isEmail, isIP } = require('validator');
const isEmpty = require('./utils/isEmpty');
const randomstring = require('randomstring');
const exec = require('child_process').execSync;

const backendOutput = {
    PORT: 80,
    WORKERS: 2,
    VERBOSE: false,
    AUTH_SECRET: "secret key",
    BASE_URL: 'http://localhost',
    ROOT_USER_USERNAME: 'root',
    ROOT_USER_EMAIL: 'admin@example.com',
    ROOT_USER_PASSWORD: 'root',
    ROOT_USER_FIRST_NAME: 'Admin',
    ROOT_USER_LAST_NAME: 'User',
    MONGO_URI: 'mongodb://localhost:27017',
    MONGO_DATABASE: 'crumble',
    REGISTER_ENABLED: false,
};

let frontendOutput = {
    REACT_APP_SITE_TITLE: 'Crumble',
    REACT_APP_BACKEND_URL: 'http://localhost',
    REACT_APP_DEMO: false,
    REACT_APP_REGISTER_ENABLED: false,
};

(async () => {
    const arg = process.argv[2];

    console.log(`received command: ${arg}`.cyan);

    console.log("");
    console.log("♥♥♥".green + " ♥♥♥".white + " ♥♥♥".red);
    console.log("♥♥♥".green + " ♥♥♥".white + " ♥♥♥".red);
    console.log("♥♥♥".green + " ♥♥♥".white + " ♥♥♥".red);
    console.log("");
    console.log("Honeyside".yellow);
    console.log(`Crumble v${pkg.version} Installer`.yellow);
    console.log("");

    if (!['setup', 'rebuild', 'start', 'stop', 'restart'].includes(arg)) {
        console.log("");
        console.log(`invalid command: ${arg}`.red);
        console.log("");
        return;
    }

    let response, baseUrl, email, username, password, firstName, lastName, secret;

    if (arg === 'setup') {
        response = await prompts({
            type: 'text',
            name: 'value',
            message: 'Your domain or ip address',
            validate: (e) => (isFQDN(e) || isIP(e)) || `Must be a valid domain or ip address`,
        });

        baseUrl = 'http://' + response.value;
        backendOutput['BASE_URL'] = baseUrl;
        frontendOutput['REACT_APP_BACKEND_URL'] = baseUrl;

        console.log('You will need an admin user account in order to manage other users.');
        console.log('You can now enter username, email, password, first name and last name for such account.');
        console.log('If you leave them blank, defaults in square parenthesis [] will be used.');

        response = await prompts({
            type: 'text',
            name: 'value',
            message: 'Username [admin]',
        });

        username = response.value;
        if (isEmpty(username)) username = 'admin';
        backendOutput['ROOT_USER_USERNAME'] = username;

        response = await prompts({
            type: 'text',
            name: 'value',
            message: 'Your Email',
            validate: (e) => isEmail(e) || `Must be a valid email`,
        });

        email = response.value;
        backendOutput['ROOT_USER_EMAIL'] = email;

        response = await prompts({
            type: 'text',
            name: 'value',
            message: 'Password [admin]',
        });

        console.log('Your email will be used to generate a Let\'s Encrypt SSL certificate for the domain.');

        password = response.value;
        if (isEmpty(password)) password = 'admin';
        backendOutput['ROOT_USER_PASSWORD'] = password;

        response = await prompts({
            type: 'text',
            name: 'value',
            message: 'First name [Admin]',
        });

        firstName = response.value;
        if (isEmpty(firstName)) firstName = 'Admin';
        backendOutput['ROOT_USER_FIRST_NAME'] = firstName;

        response = await prompts({
            type: 'text',
            name: 'value',
            message: 'Last name [User]',
        });

        lastName = response.value;
        if (isEmpty(lastName)) lastName = 'User';
        backendOutput['ROOT_USER_LAST_NAME'] = lastName;

        console.log('We need a secret string to encrypt user tokens.');
        console.log('You can input your own (random) set of characters or you can leave blank to generate a random secret.');

        response = await prompts({
            type: 'text',
            name: 'value',
            message: 'Secret [generate random]',
        });

        secret = response.value;
        if (isEmpty(secret)) secret = randomstring.generate({ length: 32, charset: 'alphabetic' });
        backendOutput['AUTH_SECRET'] = secret;

        console.log('');
        console.log('Configuration complete!'.green);
        console.log('Will now begin installation'.yellow);
        console.log('');

        let backendOutputString = '';
        let frontendOutputString = '';

        Object.keys(backendOutput).forEach(key => {
            backendOutputString += key;
            backendOutputString += '=';
            backendOutputString += backendOutput[key];
            backendOutputString += '\n';
        });

        Object.keys(frontendOutput).forEach(key => {
            frontendOutputString += key;
            frontendOutputString += '=';
            frontendOutputString += frontendOutput[key];
            frontendOutputString += '\n';
        });

        exec(`echo "${backendOutputString}" >> "../backend/.env"`);
        exec(`echo "${frontendOutputString}" >> "../frontend/.env"`);
    }

    if (['setup', 'rebuild'].includes(arg)) {
        response = exec('grep \'^NAME\' /etc/os-release');

        const os = response.toString();

        response = exec('lsb_release -r');

        const version = response.toString();

        if (!os.includes('Ubuntu')) {
            console.log('Current OS is not Ubuntu. Aborting.'.red);
            console.log('If you are running this on Ubuntu, please contact Honeyside Support.');
            return process.exit(0);
        }

        if (!version.includes('20.04') && !version.includes('18.04')) {
            console.log('This is not a supported Ubuntu version.'.red);
            console.log('The only supported versions are 20.04 LTS and 18.04 LTS');
            console.log('If you are running this on a correct version, please contact Honeyside Support.');
            return process.exit(0);
        }

        console.log('installing MongoDB...'.yellow);

        console.log('installing gnupg...');
        exec('sudo apt-get install gnupg -y');
        console.log('adding apt-key for MongoDB...')
        exec('wget -qO - https://www.mongodb.org/static/pgp/server-4.4.asc | sudo apt-key add -');

        console.log('adding repository for MongoDB...');
        if (version.includes('20.04')) {
            exec('echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/4.4 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-4.4.list');
        } else {
            exec('echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu bionic/mongodb-org/4.4 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-4.4.list');
        }

        console.log('apt-get update...');
        exec('sudo apt-get update')
        console.log('apt-get install...');
        exec('sudo apt-get install -y mongodb-org')

        console.log('starting MongoDB...'.yellow);

        console.log('daemon-reload...');
        exec('sudo systemctl daemon-reload');
        console.log('start mongod...');
        exec('sudo systemctl start mongod');
        console.log('enable mongod...');
        exec('sudo systemctl enable mongod');

        console.log('MongoDB ok'.green);

        console.log('');

        console.log('Configuring iptables...'.yellow);
        exec('iptables -F');
        exec('iptables -X');
        exec('iptables -t nat -F');
        exec('iptables -t nat -X');
        exec('iptables -t mangle -F');
        exec('iptables -t mangle -X');
        exec('iptables -P INPUT ACCEPT');
        exec('iptables -P FORWARD ACCEPT');
        exec('iptables -P OUTPUT ACCEPT');
        exec('iptables -I INPUT -j ACCEPT');
        exec('sudo /sbin/iptables-save');
        console.log('iptables ok'.green);

        console.log('');

        console.log(`${arg === 'setup' ? 'installing' : 'rebuilding'} Crumble backend...`.yellow);
        console.log('installing backend node modules...');
        console.log('this might take a while, depending on your machine cpu and ram');
        exec('cd ../backend && yarn');
        console.log('starting backend...');
        try {
            exec('pm2 delete --silent Crumble', {stdio : 'pipe'});
        } catch (e) {}
        exec('cd ../backend && pm2 start index.js --name Crumble');
        exec('pm2 save');
        exec('pm2 startup');
        console.log('Crumble backend started'.green);

        console.log('');

        console.log(`${arg === 'setup' ? 'installing' : 'rebuilding'} Crumble frontend...`.yellow);
        console.log('installing frontend node modules...');
        console.log('this might take a while');
        exec('cd ../frontend && yarn');
        console.log('building frontend...');
        console.log('this might take a while');
        exec('cd ../frontend && yarn build');
        console.log('Clover frontend ok'.green);
    }

    if (arg === 'start') {
        try {
            exec('cd ../backend && pm2 start index.js --name Crumble');
        } catch (e) {}
    }

    if (arg === 'restart') {
        try {
            exec('pm2 restart Crumble', {stdio : 'pipe'});
        } catch (e) {}
    }

    if (arg === 'stop') {
        try {
            exec('pm2 stop Crumble', {stdio : 'pipe'});
        } catch (e) {}
    }

    if (arg === 'stop') {
        console.log("");
        console.log(`Crumble has been stopped.`.green);
        console.log("");
    } else {
        console.log("");
        console.log(`Crumble v${pkg.version} ${arg === 'setup' ? 'setup' : 'restart'} complete!`.green);
        if (arg === 'setup') {
            console.log(`You should now be able to access Crumble at ${baseUrl}`);
        }
        console.log("");
    }
})();
