const mongoose = require('mongoose');
const config = require("../../config");
const {mongo} = config;
const {log} = require("express-power");

const connectDB = () => new Promise(async resolve => {
    const uri = mongo.uri || `mongodb${mongo.srv ? "+srv" : ""}://${mongo.username}:${encodeURIComponent(mongo.password)}@${mongo.hostname}:${mongo.port}/${mongo.database}?authSource=${mongo.authenticationDatabase}`;

    // compatibility with mongoose 6.x.x
    mongoose.Schema.Types.Embedded = mongoose.Schema.Types.Subdocument;

    // connect to mongo
    try {
        await mongoose.connect(uri, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            ssl: false,
        }, null);
        log("Connected to Mongo".green);
        resolve(true);
    } catch (e) {
        log("Could not connect to Mongo".red);
        if (config.verbose) console.error(e);
        resolve(false);
    }
});

module.exports = connectDB;
