const { Shortner } = require("../models");

const addShortner = async (data) => {
  const shortURL = await Shortner.findOne({ target: data.target });
  if (shortURL) {
    return shortURL;
  }
  return new Shortner({
    target: data.target,
  }).save();
};

const getShortUrl = async (id) => {
  return Shortner.findById(id);
};

module.exports = { addShortner, getShortUrl };
