const express = require('express');
const router = express.Router();

router.use('/auth', require('./auth'));
router.use('/keys', require('./keys'));
router.use('/stats', require('./stats'));
router.use('/shortner', require('./shortner'));
router.use('/users', require('./users'));
router.use('/vault', require('./vault'));
router.use('/info', require('./info'));
router.use('/updates', require('./updates'));

module.exports = router;
