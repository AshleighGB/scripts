const stats = require("../../dao/stats");
const shield = require('../../dao/shield');

module.exports = async (req, res) => {
  let result = {};

  if (!req.user.roles.includes('admin') && !req.user.roles.includes('root')) {
    result = await stats.dataSizeVariation(req.user.id);
  } else {
    result = await stats.dataSizeVariation();
  }

  res.status(200).json(result);
};
