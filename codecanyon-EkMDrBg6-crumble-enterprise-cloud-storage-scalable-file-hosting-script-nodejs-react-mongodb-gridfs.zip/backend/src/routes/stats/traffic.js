const stats = require("../../dao/stats");

module.exports = async (req, res) => {
  const days = req.fields.days;

  let result;

  if (!req.user.roles.includes('admin') && !req.user.roles.includes('root')) {
    result = await stats.getTraffic({days: days || 7, user: req.user.id});
  } else {
    result = await stats.getTraffic({days: days || 7 });
  }

  res.status(200).json(result);
};
