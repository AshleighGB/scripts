const stats = require("../../dao/stats");
const mongoose = require('mongoose');
const { ObjectId } = mongoose.Types;

module.exports = async (req, res) => {
  let result;

  if (!req.user.roles.includes('admin') && !req.user.roles.includes('root')) {
    result = await stats.getCounts({user: req.user.id});
  } else {
    result = await stats.getCounts({});
  }

  res.status(200).json(result);
};
