const { findKeyById } = require("../../dao/keys");

module.exports = async (req, res) => {
  const { ids } = req.fields;

  let key, tmp;
  const result = [];

  for (let id of ids) {
    console.log(id)
    try {
      key = await findKeyById(id);
    } catch (e) {
      return res.status(500).json({ status: 'error', message: 'database read error' });
    }

    try {
      tmp = await key.delete();
    } catch (e) {
      return res.status(500).json({ status: 'error', message: 'database write error' });
    }

    tmp = tmp.toObject();
    tmp.id = tmp._id;

    result.push(tmp);
  }

  res.status(200).json({ status: "success", result });
};
