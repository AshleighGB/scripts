const { findKeyById } = require("../../dao/keys");

module.exports = async (req, res) => {
  const { id } = req.fields;

  let key, result;

  try {
    key = await findKeyById(id);
  } catch (e) {
    return res.status(500).json({ status: 'error', message: 'database read error' });
  }

  if (!key) {
    return res.status(404).json({ status: 'error', message: 'user not found' });
  }

  try {
    result = await key.delete();
  } catch (e) {
    return res.status(500).json({ status: 'error', message: 'database write error' });
  }

  result = result.toObject();
  result.id = result._id;

  res.status(200).json({ status: "success", result });
};
