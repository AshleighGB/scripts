const { insertKey } = require("../../dao/keys");
const isEmpty = require('../../utils/isEmpty');
const dictionary = require('../../dictionaries/keys');
const config = require('../../../config');
const secret = config.secret || 'default secret';
const jwt = require('jsonwebtoken');

module.exports = async (req, res) => {
  let { title } = req.fields;

  let key;

  let errors = {};

  if (isEmpty(title)) {
    errors.title = dictionary['title-required'];
  }

  if (Object.keys(errors).length > 0) {
    return res.status(400).json({ status: "error", ...errors });
  }

  try {
    key = await insertKey({
      title,
      user: req.user.id,
      userObject: {
        ...req.user,
        password: undefined,
      },
    });
  } catch (e) {
    return res.status(500).json({ status: 'error', message: 'database write error', generic: true });
  }

  jwt.sign(
    {
      type: 'key',
      id: key._id,
      user: key.user,
      title: key.title,
    }, secret,
    { expiresIn: Number.MAX_SAFE_INTEGER },
    async (err, token) => {
      if (err) return res.status(500).json({ status: 'error', message: 'error signing token' });
      key.token = token;
      await key.save();

      key = key.toObject();
      key.id = key._id;

      res.status(200).json({ status: "success", key });
    }
  );
};
