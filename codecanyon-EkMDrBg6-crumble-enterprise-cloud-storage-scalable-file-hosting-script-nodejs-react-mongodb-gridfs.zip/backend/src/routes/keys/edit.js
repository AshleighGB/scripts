const { findKeyById } = require("../../dao/keys");
const isEmpty = require('../../utils/isEmpty');
const dictionary = require('../../dictionaries/keys');

module.exports = async (req, res) => {
  let { id, title } = req.fields;

  let key, result;

  let errors = {};

  try {
    key = await findKeyById(id);
  } catch (e) {
    return res.status(500).json({ status: 'error', message: 'database read error' });
  }

  if (!key) {
    return res.status(404).json({ status: 'error', message: 'user not found' });
  }

  if (isEmpty(title)) {
    errors.title = dictionary['title-required'];
  } else {
    key.title = title;
  }

  if (Object.keys(errors).length > 0) {
    return res.status(400).json({ status: 'error', ...errors });
  }

  try {
    result = await key.save();
  } catch (e) {
    return res.status(500).json({ status: 'error', message: 'database write error' });
  }

  result = result.toObject();
  result.id = result._id;

  res.status(200).json({ status: "success", result });
};
