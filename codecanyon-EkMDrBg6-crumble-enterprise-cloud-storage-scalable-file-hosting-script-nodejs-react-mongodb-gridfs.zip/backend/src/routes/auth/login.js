const router = require('express').Router();
const config = require('../../../config');
const secret = config.secret || 'default secret';
const jwt = require('jsonwebtoken');
const isEmpty = require('../../utils/isEmpty');
const regexUsername = require('../../utils/regexUsername');
const argon2 = require('argon2');
const { findUserByUsername, findUserByEmail } = require('../../dao/users');
const dictionary = require('../../dictionaries/auth');

router.post('*', async (req, res) => {
  let { username, password } = req.fields;

  if (isEmpty(username)) {
    return res.status(400).json({
      status: 'error',
      message: 'username required',
      username: dictionary['username-required']
    });
  }

  if (isEmpty(password)) {
    return res.status(400).json({
      status: 'error',
      message: 'password required',
      username: dictionary['password-required']
    });
  }

  username = regexUsername(username);

  let user;

  try {
    user = await findUserByUsername(username);
  } catch (e) {
    return res.status(500).json({ status: 'error', message: 'database read error' });
  }

  if (!user) {
    try {
      user = await findUserByEmail(username);
    } catch (e) {
      return res.status(500).json({ status: 'error', message: 'database read error' });
    }
  }

  if (!user) {
    return res.status(400).json({ status: 'error', message: 'user not found', username: dictionary['user-not-found'] });
  }

  argon2.verify(user.password, password).then(async valid => {
    if (valid) {
      jwt.sign(
        {
          id: user._id,
          username: user.username,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          roles: user.roles,
          lastLogin: user.lastLogin
        }, secret,
        { expiresIn: Number.MAX_SAFE_INTEGER },
        async (err, token) => {
          if (err) return res.status(500).json({ status: 'error', message: 'error signing token' });
          user.lastLogin = Date.now();
          await user.save();
          res.status(200).json({ status: 'ok', token });
        }
      );
    } else {
      res.status(400).json({ status: 'error', message: 'wrong password', password: 'wrong password' });
    }
  });
});

module.exports = router;
