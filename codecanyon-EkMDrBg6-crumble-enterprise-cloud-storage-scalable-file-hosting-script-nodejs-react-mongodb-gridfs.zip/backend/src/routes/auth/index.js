const express = require('express');
const router = express.Router();
const passport = require('passport');

router.use('/login', require('./login'));
router.use('/user', passport.authenticate('jwt', {session: false, failureRedirect: '/api/auth/unauthorized'}, null), require('./user'));
router.use('/update-profile', passport.authenticate('jwt', {session: false, failureRedirect: '/api/auth/unauthorized'}, null), require('./update-profile'));
router.use('/change-password', passport.authenticate('jwt', {session: false, failureRedirect: '/api/auth/unauthorized'}, null), require('./change-password'));
router.use('/unauthorized', require('./unauthorized'));

module.exports = router;
