module.exports = (req, res) => {
  res.status(200).json([{
    timestamp: '2022-02-03T20:19:39Z',
    title: 'Sharing link update',
    content: '[1.1.0] File links can now be copied to clipboard directly from the vault section. Bug fixing.'
  }, {
    timestamp: '2021-09-12T20:19:39Z',
    title: 'Welcome to Crumble!',
    content: 'Version 1.0.0 has been released.'
  }]);
};
