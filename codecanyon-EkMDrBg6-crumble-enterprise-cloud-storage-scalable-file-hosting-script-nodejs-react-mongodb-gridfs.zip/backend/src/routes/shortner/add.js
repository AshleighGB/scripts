const { addShortner } = require("../../dao/shortner");
const isEmpty = require('../../utils/isEmpty');
const config = require('../../../config');

module.exports = async (req, res) => {
  let { target } = req.fields;

  if (isEmpty(target)) {
    return res.status(400).json({ target: 'target required' });
  }

  const shortner = await addShortner({ target });

  res.status(200).json({ status: "success", shortner, url: `${config.baseUrl}/s/${shortner._id}` });
};
