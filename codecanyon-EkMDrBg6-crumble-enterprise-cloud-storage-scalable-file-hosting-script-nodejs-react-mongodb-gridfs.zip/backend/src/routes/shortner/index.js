const express = require('express');
const router = express.Router();
const passport = require('passport');

router.use('/add', passport.authenticate('jwt', {session: false, failureRedirect: '/api/auth/unauthorized'}, null), require('./add'));

module.exports = router;
