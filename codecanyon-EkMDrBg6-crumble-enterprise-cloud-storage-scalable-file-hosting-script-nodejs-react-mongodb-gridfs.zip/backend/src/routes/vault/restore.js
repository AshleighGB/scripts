const { findShieldGarbageIncluded } = require("../../dao/shield");
const { Log, } = require("../../models");
const info = require('../../../info');

module.exports = async (req, res) => {
    const shield = await findShieldGarbageIncluded(req.fields.shield);

    if (!shield) return res.status(404).json({ error: 'file not found' });

    if (shield.owner.toString() === req.user.id.toString() || req.user.roles.includes('admin') || req.user.roles.includes('root')) {
        shield.garbage = false;

        try {
            Log({ key: 'restore', shield, user: req.user.id, build: info.build, version: info.version }).save();
            await shield.save();
        } catch (e) {
            return res.status(500).json({ status: "error", message: "error while restoring file" });
        }

        res.status(200).json({ shield, status: "restore" });
    } else {
        res.status(401).json({ error: 'unauthorized user' });
    }
};
