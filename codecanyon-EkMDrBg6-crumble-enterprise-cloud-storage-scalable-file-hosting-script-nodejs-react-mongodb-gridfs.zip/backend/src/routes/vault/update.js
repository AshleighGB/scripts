const { findShield } = require('../../dao/shield');
const regexTags = require('../../utils/regexTags');
const isEmpty = require('../../utils/isEmpty');

module.exports = async (req, res) => {
  let { shield, description, tags, auth } = req.fields;

  let file, result;

  try {
    file = await findShield(shield);
  } catch (e) {
    return res.status(500).json({ status: 'error', message: 'database read error' });
  }

  if (!file) {
    return res.status(404).json({ status: 'error', message: 'user not found' });
  }

  if (file.owner.toString() !== req.user.id.toString() && !user.roles.includes('admin') && !user.roles.includes('root')) {
    return res.status(500).json({ status: 'error', message: 'user can not edit this file', generic: true });
  }

  file.description = description;
  file.auth = auth;

  if (isEmpty(tags)) {
    file.tags = [];
  } else {
    file.tags = regexTags((tags || '').split(','));
  }

  try {
    result = await file.save();
  } catch (e) {
    return res.status(500).json({ status: 'error', message: 'database write error' });
  }

  result = result.toObject();
  result.id = result._id;
  result.fullName = `${result.firstName} ${result.lastName}`;

  res.status(200).json({ status: "success", result });
};
