const { createModel } = require("mongoose-gridfs");
const { findShield } = require("../../dao/shield");
const { findSession } = require("../../dao/sessions");
const { Log, } = require("../../models");
const info = require('../../../info');
const { findUserById } = require('../../dao/users');
const isEmpty = require('../../utils/isEmpty');

module.exports = async (req, res) => {
    const File = createModel();

    if (isEmpty(req.params.id)) {
        return res.status(400).json({ error: 'id required' });
    }

    let shield;
    try {
        shield = await findShield(req.params.id.split('.')[0]);
    } catch (e) {
        return res.status(500).json({ error: 'database read error' });
    }

    if (!shield) return res.status(404).json({ error: 'file not found' });

    let session;

    if (shield.auth) {
        try {
            session = await findSession(req.query.signature);
        } catch (e) {
            return res.status(500).json({ error: 'database signature error' });
        }
        if (!session) return res.status(401).json({ error: 'invalid or expired signature' });

        let ok = false;

        if (shield.owner.toString() === session.user.toString()) {
            ok = true;
        }

        if (!ok) {
            const user = await findUserById(session.user);
            if (!user || !(user.roles || []).includes('admin')) {
                return res.status(401).json({ error: 'unauthorized user' });
            }
        }
    }

    if (req.query.thumbnail && (!shield.thumbnail || !shield.thumbnail[req.query.thumbnail])) {
        return res.status(404).json({ error: `no ${req.query.thumbnail} thumbnail for this file` });
    }

    File.findById(req.query.thumbnail ? shield.thumbnail[req.query.thumbnail] : shield.file, (error, file) => {
        shield.views++;
        shield.save();
        Log({ key: 'read', shield, size: file.length, user: session ? session.user : shield.user, build: info.build, version: info.version, thumbnail: !!req.query.thumbnail }).save();
        const readStream = file.read();
        readStream.pipe(res);
        res.set('Content-Length', file.length);
        res.set('Content-Type', file.contentType);
        res.set('Content-Disposition', req.query.action === 'download' ? `attachment; filename="${shield.name}"` : `filename="${shield.name}"`);
        res.status(200);
    });
};
