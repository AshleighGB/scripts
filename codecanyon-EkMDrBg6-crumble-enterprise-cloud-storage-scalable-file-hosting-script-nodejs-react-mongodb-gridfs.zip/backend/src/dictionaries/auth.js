const dictionary = {
  'invalid-email': 'invalid email address',
  'username-already-in-use': 'username already in use',
  'email-already-in-use': 'email already in use',
  'first-name-required': 'first name is required',
  'last-name-required': 'last name is required',
  'email-required': 'email is required',
  'username-required': 'username is required',
  'password-required': 'password is required',
  'password-too-short': 'password too short (at least 6 characters)',
  'user-not-found': 'user not found',
};

module.exports = dictionary;
