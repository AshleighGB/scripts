const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const ShortnerSchema = new Schema({
  target: {
    type: String,
    default: 'generic',
  },
});

const Shortner = mongoose.model('Shortner', ShortnerSchema);

module.exports = Shortner;
