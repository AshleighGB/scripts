import axios from 'axios';
import Config from '../../config';

const deleteKey = ({
  id, actions, setOpen
}) => async (dispatch) => {
  actions.setSubmitting(true);

  const onSuccess = (response) => {
    const { result } = response.data;
    dispatch({ type: 'keys-deleted', key: result });
    dispatch({ type: 'snack', content: `key ${result.title} deleted`, severity: 'success' });
    setOpen(false);
    return response;
  };

  const onError = (error) => {
    if (error.response) {
      console.log(error.response);
    }
    dispatch({ type: 'snack', content: 'error while deleting key', severity: 'error' });
    return error;
  };

  try {
    const response = await axios.post(`${Config.url}/api/keys/delete`, {
      id,
    });
    onSuccess(response);
  } catch (error) {
    onError(error);
  }

  actions.setSubmitting(false);
};

export default deleteKey;
