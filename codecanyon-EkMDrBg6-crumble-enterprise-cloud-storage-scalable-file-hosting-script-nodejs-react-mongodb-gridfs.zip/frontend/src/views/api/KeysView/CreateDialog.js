import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import { Button, TextField } from '@material-ui/core';
import DialogActions from '@material-ui/core/DialogActions';
import Dialog from '@material-ui/core/Dialog';
import React from 'react';
import PropTypes from 'prop-types';
import { Formik } from 'formik';
import { useDispatch } from 'react-redux';
import createKey from '../../../actions/keys/createKey';

const CreateDialog = ({ open, setOpen }) => {
  const dispatch = useDispatch();

  return (
    <Formik
      initialValues={{
        title: '',
      }}
      onSubmit={(values, actions) => {
        dispatch(createKey({
          title: values.title,
          actions,
          setOpen
        }));
      }}
    >
      {({
        errors,
        handleBlur,
        handleChange,
        handleSubmit,
        handleReset,
        isSubmitting,
        touched,
        values
      }) => (
        <Dialog open={open} onClose={() => setOpen(!open)} aria-labelledby="form-dialog-title" disableBackdropClick>
          <DialogTitle id="form-dialog-title">Create new API key</DialogTitle>
          <DialogContent>
            <DialogContentText>
              Howdy! How do you want to reference your new key?
            </DialogContentText>
            <TextField
              autoFocus
              error={Boolean(touched.title && errors.title)}
              helperText={errors.title || 'Title of your API key'}
              margin="dense"
              name="title"
              onBlur={handleBlur}
              onChange={handleChange}
              label="Title"
              value={values.title}
              type="text"
              fullWidth
            />
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => {
                handleReset();
                setOpen(!open);
              }}
              color="primary"
            >
              Cancel
            </Button>
            <Button onClick={handleSubmit} color="primary" disabled={isSubmitting}>
              Create
            </Button>
          </DialogActions>
        </Dialog>
      )}
    </Formik>
  );
};

CreateDialog.propTypes = {
  open: PropTypes.bool,
  setOpen: PropTypes.func
};

export default CreateDialog;
