import React, { useState } from 'react';
import clsx from 'clsx';
import {
  Button,
  Card,
  CardActions, Dialog, DialogActions, DialogContent, DialogTitle,
} from '@material-ui/core';
import {
  makeStyles
} from '@material-ui/styles';
import DialogContentText from '@material-ui/core/DialogContentText';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import PropTypes from 'prop-types';
import logout from '../../../actions/auth/logout';

const useStyles = makeStyles(() => ({
  root: {},
  avatar: {
    height: 100,
    width: 100
  }
}));

const Logout = ({ className, ...rest }) => {
  const classes = useStyles();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [open, setOpen] = useState(false);

  return (
    <Card
      className={clsx(classes.root, className)}
      {...rest}
    >
      <CardActions>
        <Button
          color="primary"
          fullWidth
          variant="text"
          onClick={() => setOpen(true)}
        >
          Log out
        </Button>
      </CardActions>
      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">Confirmation</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Are you sure you want to log out?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)} color="primary">
            Cancel
          </Button>
          <Button onClick={() => dispatch(logout({ navigate }))} color="primary">
            Log out
          </Button>
        </DialogActions>
      </Dialog>
    </Card>
  );
};

Logout.propTypes = {
  className: PropTypes.string,
};

export default Logout;
